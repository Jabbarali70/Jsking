# Termux Basic Packages 

If you are looking for basic packages of termux then this is right tool for you. Follow the given commands and install basic packages in termux. And This Tool is made for Termux beginner.And it's a very easy to use and install. This tool is coded in python . 

## Tool Installs This packages
 
 -  python
 -  python2
 -  python2-dev
 -  python3
 -  git
 -  php 
 -  perl 
 -  bash
 -  nano
 -  curl
 -  openssl
 -  openssh
 -  wget
 -  clang
 -  help
 -  nmap
 -  w3m
 -  hydra
 -  ruby
 -  macchanger
 -  dnsutils
 -  coreutils
 -  host


This command for access the storage in termux 
termux-setup-storage.


## Installation 
 
## Termux
   ```
   $ apt install git 
   ```
   ```
   $ apt install python 
   ```
   ```
   $ git clone https://github.com/Hackertrackersj/Termux--Package
   ```
   ```
   $ cd Termux-package
   ```
   ```
   $ ls
   ```
   ```
   $ chmod +x *
   ```
   ```
   $ ls
   ```
   ```
   $ python termux-package.py
```

This will take too much time it's depends on your data connection. 

### Visit on YouTube Channel

https://www.youtube.com/c/NitroHacker

### PRACTICAL VIDEO
https://youtu.be/ibdMHfYzZNM

For Hacking Videos Subscribe

### My Website
https://official-nitrohacker.blogspot.com/
